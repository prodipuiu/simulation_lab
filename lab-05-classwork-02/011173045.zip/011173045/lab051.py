#Name: Md Sezan Mahmud Saika
#ID: 011 173 045

import math
import random
import matplotlib.pyplot as plt

random.seed(1)

#a = float(input("Enter the lower limit: "))
#b = float(input("Enter the upper limit: "))

a=0
b=5

n=[500, 1000, 5000, 10000]


integral = []
error = []


for i in n:
    fx = 0.0
    fx2 = 0.0
    fbar = 0.0
    fbar2 = 0.0
    for j in range(i):
        xi=random.uniform(a,b)
        fx = fx + (pow(xi, 2)/math.exp(xi))
        fx2 = fx2 + ((pow(xi, 2)/math.exp(xi))*(pow(xi, 2)/math.exp(xi)))

    fbar = fx/i
    #print(fbar)
    fbar2 = fx2/i
    #print(fbar2)

    integral.append((b-a)*fbar)
    p = (b-a)/math.sqrt(i)
    q = math.sqrt(fbar2-pow(fbar,2))
    error.append(p*q)


print("Integral values for different trials: ",integral)
print("Error values for different trials: ",error)


z=["500", "1000", "5000", "10000"]
plt.bar(z,integral)
plt.ylim(1.5,2)
plt.xlabel("Trials")
plt.ylabel("Integral")
plt.show()

plt.bar(z,error)
plt.ylim(0,0.10)
plt.xlabel("Trials")
plt.ylabel("Error")
plt.show()

